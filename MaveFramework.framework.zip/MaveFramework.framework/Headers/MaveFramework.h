//
//  MaveFramework.h
//  MaveFramework
//
//  Created by Christopher Susandji on 11/05/23.
//

#import <Foundation/Foundation.h>

//! Project version number for MaveFramework.
FOUNDATION_EXPORT double MaveFrameworkVersionNumber;

//! Project version string for MaveFramework.
FOUNDATION_EXPORT const unsigned char MaveFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MaveFramework/PublicHeader.h>


